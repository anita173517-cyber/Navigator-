# RAM PLAYER v20.0 — Final Ultimate Edition (Build 200)

**Package ID:** `com.harindra.iptvpro` (`versionCode = 200`, `versionName = "20.0"`)  
**Engine:** AndroidX Media3 `1.11.1` (`exoplayer`, `hls`, `dash`, `rtsp`, `ui`, `session`, `okhttp`) • WorkManager `2.9.1`

## Highlights
- **512MB Low-RAM Safe Mode & 4GB High-Performance Mode** (`DeviceOptimizationProfile` with automatic memory-pressure fallback).
- **Dedicated Media3 `MediaSessionService`** (`RamPlayerPlaybackService.kt`) with single authoritative player session.
- **Independent Per-Profile / Per-Playlist WorkManager Auto-Refresh** (`PlaylistRefreshWorker.kt`).
- **Genuine Recycle Bin** for soft-deleted profiles & custom channel groups (separate from Hide/Unhide & Channel Blacklist).
- **Transactional Backup & Restore** (`SXBK_V20`/`SXBK_V19`, AES-256-GCM password encryption, atomic rollback).
- **Real PCM Audio Delay (`AudioDelayProcessor.kt`), Generation-Safe Subtitle Delay, Honest Passthrough vs Offload, Real HDR Detection, Voice Search, Searchable 24-Category Settings Hub, App Health Dashboard, and Privacy Controls.**

## Build & Verify
```bash
python3 scripts/verify_project.py
gradle --no-daemon testDebugUnitTest assembleDebug assembleRelease
```
